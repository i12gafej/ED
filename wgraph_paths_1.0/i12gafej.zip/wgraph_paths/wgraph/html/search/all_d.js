var searchData=
[
  ['ref_50',['Ref',['../classMatrix.html#a86081140d8c1f043687455f8f549028c',1,'Matrix::Ref()'],['../classWNode.html#a9a3d11e76bacea5b1e83b35658d70c06',1,'WNode::Ref()'],['../classWEdge.html#ad9e2ef9358fe036a581e6c5287c9d488',1,'WEdge::Ref()'],['../classWGraph.html#afe1fa07c6bab3f23c097c9bde88c4320',1,'WGraph::Ref()']]],
  ['resize_51',['resize',['../classMatrix.html#a523e1258ca515b86a23debba6661e649',1,'Matrix']]],
  ['rows_52',['rows',['../classMatrix.html#a5330adf02b284293259eb9f7c9acaa99',1,'Matrix']]]
];
