var searchData=
[
  ['resize_114',['resize',['../classMatrix.html#a523e1258ca515b86a23debba6661e649',1,'Matrix']]],
  ['rows_115',['rows',['../classMatrix.html#a5330adf02b284293259eb9f7c9acaa99',1,'Matrix']]]
];
