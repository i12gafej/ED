var searchData=
[
  ['city_5fdata_66',['City_data',['../structCity__data.html',1,'']]]
];
