var searchData=
[
  ['edge_87',['edge',['../classWGraph.html#a53bd3fe047a347d2eeb78c46bdba854d',1,'WGraph::edge(NodeRef u, NodeRef v) const'],['../classWGraph.html#a6e2d42ce4dfd702808e9690f94f5d60e',1,'WGraph::edge(size_t u_label, size_t v_label) const']]]
];
